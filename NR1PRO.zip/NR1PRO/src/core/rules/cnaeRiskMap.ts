export const cnaeRiskMap: any = {
  "6201-5/01": [
    { risk: "Ergonomia", level: "MEDIUM" },
    { risk: "Estresse", level: "HIGH" }
  ]
};